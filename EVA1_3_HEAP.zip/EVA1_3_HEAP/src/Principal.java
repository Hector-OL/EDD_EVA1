public class Principal {

    public static void main(String[] args) {
        
        int i = 10;
        Principal pObj = new Principal();
        System.out.println(i);
        System.out.println(pObj);
        pObj = null;
        
    }
    
}

