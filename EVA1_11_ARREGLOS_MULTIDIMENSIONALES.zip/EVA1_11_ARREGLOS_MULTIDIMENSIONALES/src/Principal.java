public class Principal {


    public static void main(String[] args) {
        //ARREGLO DE DOS DIMENSIONES --> MATRIZ
        int aDatos[][] = new int[3][4];
        System.out.println("Direccion del arreglo "+ aDatos);
        System.out.println("Tamaño del arreglo "+ aDatos.length);
        
        System.out.println("Direccion del arreglo aDatos[0]"+ aDatos[0]);
        System.out.println("Tamaño del arreglo "+ aDatos[0].length);
        
        System.out.println("Valor de la posicion Datos[0][0]"+ aDatos[0][0]);

    }
    
}
